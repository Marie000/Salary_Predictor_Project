# Salary Predictor

I am working here on organizing my code for my salary predictor in a more modular fashion, and gradually integrating mlops principles.

This is still very much a work in progress, so a lot of the files are not done and/or have not been tested yet. 

It should improve in the next few days/weeks (as of May 29, 2024)

The original notebook for this project can be found here:
https://github.com/Marie000/Linkedin-predictor-model/blob/main/Copy_of_LinkedIn_Salary_Predictor.ipynb

Link to the working demo of this project can be found here:
https://huggingface.co/spaces/marie000/salary-predictor